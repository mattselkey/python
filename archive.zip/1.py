# Example
# Save as .py, chmod +x, run $[@]python3 script.py

def main():
    print('Hello world')

#see https://docs.python.org/3/library/__main__.html
if __name__ == '__main__':
    main()